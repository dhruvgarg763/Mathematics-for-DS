# Mathematics-for-data-Science
Repository for Stamatics Project 22' - Mathematics for Data Science 

### WEEK-1

* There are three jupyter notebooks in the week-1 assignment.
* Notebook one is for Numpy
* Notebook two is for data-handling of 'Salaries.csv' using pandas
* Notebook three is for data-handling of 'Ecommerce Purchases' using pandas

### WEEK-2

* There are two jupyter notebooks in the week-1 assignment.
* Notebook one is for matplotlib
* Notebook two is for seaborn


